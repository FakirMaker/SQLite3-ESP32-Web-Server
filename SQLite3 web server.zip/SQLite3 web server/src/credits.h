#ifndef CREDITS_H
#define CREDITS_H

#define WIFI_SSID "InterContinental_Wi-Fi"
#define WIFI_PASS ""

#endif